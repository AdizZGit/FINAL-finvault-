package com.bank.model;

public enum Role {
	USER,
	ADMIN,
	EMPLOYEE

}
