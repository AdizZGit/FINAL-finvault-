package com.bank.model;

public enum TransactionType {
    DEPOSIT, WITHDRAW, TRANSFER
}
