package com.bank.model;

public enum Designation {
	    TRANSACTION_OFFICER, 
	    ACCOUNT_MANAGER,
	    CARD_MANAGER,
	    LOAN_OFFICER	
}
