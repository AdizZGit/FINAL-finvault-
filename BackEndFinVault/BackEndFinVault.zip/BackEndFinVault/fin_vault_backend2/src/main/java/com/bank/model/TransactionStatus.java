package com.bank.model;

public enum TransactionStatus {
    PENDING, SUCCESS, FAILED
}
